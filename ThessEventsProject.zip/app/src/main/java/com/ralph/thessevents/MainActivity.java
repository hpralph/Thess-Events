package com.ralph.thessevents;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private FrameLayout root;
    private WebView appWeb, fbWeb;
    private SharedPreferences prefs;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();

    private final LinkedHashSet<String> fbEventLinks = new LinkedHashSet<>();
    private final ArrayList<String> fbDiscoveryQueue = new ArrayList<>();
    private final ArrayList<String> fbDetailQueue = new ArrayList<>();
    private int discoveryIndex = 0, detailIndex = 0;
    private boolean refreshRunning = false;
    private boolean loginMode = false;

    private static final String[] FB_SEARCHES = new String[] {
            "Thessaloniki events", "Θεσσαλονίκη εκδηλώσεις",
            "Thessaloniki concert", "Thessaloniki live music",
            "Thessaloniki party", "Thessaloniki DJ",
            "Thessaloniki theatre", "Θεσσαλονίκη θέατρο",
            "Thessaloniki exhibition", "Θεσσαλονίκη έκθεση",
            "Thessaloniki festival", "Θεσσαλονίκη φεστιβάλ",
            "Thessaloniki workshop", "Thessaloniki meetup",
            "Thessaloniki market", "Thessaloniki family events"
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("thess_events", MODE_PRIVATE);
        buildUi();
        appWeb.loadUrl("file:///android_asset/index.html");
    }

    private void buildUi() {
        root = new FrameLayout(this);
        setContentView(root);

        appWeb = new WebView(this);
        configure(appWeb);
        appWeb.addJavascriptInterface(new AppBridge(this), "Android");
        root.addView(appWeb, new FrameLayout.LayoutParams(-1,-1));

        fbWeb = new WebView(this);
        configure(fbWeb);
        fbWeb.setVisibility(View.GONE);
        root.addView(fbWeb, new FrameLayout.LayoutParams(-1,-1));

        fbWeb.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (loginMode) return;
                if (!refreshRunning) return;
                main.postDelayed(() -> handleFacebookPage(url), 1600);
            }
        });
    }

    private void configure(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setUserAgentString(s.getUserAgentString().replace("; wv", ""));
        w.setWebChromeClient(new WebChromeClient());
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
    }

    private void toast(String s) { main.post(() -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show()); }

    public class AppBridge {
        Context c;
        AppBridge(Context c){this.c=c;}

        @JavascriptInterface public String getEvents() {
            return prefs.getString("events_json", "[]");
        }
        @JavascriptInterface public String getLastUpdated() {
            return prefs.getString("last_updated", "");
        }
        @JavascriptInterface public String getStatus() {
            return prefs.getString("status", "Ready");
        }
        @JavascriptInterface public boolean hasFacebookSession() {
            String cookies = CookieManager.getInstance().getCookie("https://www.facebook.com/");
            return cookies != null && (cookies.contains("c_user=") || cookies.contains("xs="));
        }
        @JavascriptInterface public void loginFacebook() {
            main.post(() -> {
                loginMode = true;
                fbWeb.setVisibility(View.VISIBLE);
                appWeb.setVisibility(View.GONE);
                fbWeb.loadUrl("https://www.facebook.com/events/");
                toast("Log into Facebook, then press Android Back.");
            });
        }
        @JavascriptInterface public void refresh() {
            main.post(() -> startRefresh());
        }
        @JavascriptInterface public String getLocation() {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 41);
                return "";
            }
            try {
                LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
                Location loc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if(loc==null) loc=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if(loc==null) return "";
                return loc.getLatitude()+","+loc.getLongitude();
            } catch(Exception e){ return ""; }
        }
    }

    @Override public void onBackPressed() {
        if (loginMode) {
            loginMode=false;
            fbWeb.setVisibility(View.GONE);
            appWeb.setVisibility(View.VISIBLE);
            appWeb.evaluateJavascript("window.onFacebookLoginClosed && window.onFacebookLoginClosed()", null);
            return;
        }
        if (appWeb.canGoBack()) appWeb.goBack(); else super.onBackPressed();
    }

    private void status(String s) {
        prefs.edit().putString("status",s).apply();
        appWeb.evaluateJavascript("window.setNativeStatus && window.setNativeStatus("+JSONObject.quote(s)+")",null);
    }

    private void startRefresh() {
        if (refreshRunning) return;
        String cookies = CookieManager.getInstance().getCookie("https://www.facebook.com/");
        if (cookies == null || !cookies.contains("c_user=")) {
            status("Facebook login needed");
            appWeb.evaluateJavascript("window.needFacebookLogin && window.needFacebookLogin()",null);
            return;
        }
        refreshRunning=true;
        fbEventLinks.clear(); fbDiscoveryQueue.clear(); fbDetailQueue.clear();
        discoveryIndex=0; detailIndex=0;
        status("Searching Facebook Events…");

        fbDiscoveryQueue.add("https://www.facebook.com/events/");
        fbDiscoveryQueue.add("https://www.facebook.com/events/discovery/");
        for(String q:FB_SEARCHES) {
            fbDiscoveryQueue.add("https://www.facebook.com/events/search/?q="+
                    URLEncoder.encode(q, StandardCharsets.UTF_8));
        }
        loadNextDiscovery();
    }

    private void loadNextDiscovery() {
        if(discoveryIndex>=fbDiscoveryQueue.size()) {
            fbDetailQueue.addAll(fbEventLinks);
            if(fbDetailQueue.size()>120) fbDetailQueue.subList(120,fbDetailQueue.size()).clear();
            status("Reading "+fbDetailQueue.size()+" Facebook events…");
            loadNextDetail();
            return;
        }
        String url=fbDiscoveryQueue.get(discoveryIndex++);
        fbWeb.loadUrl(url);
    }

    private boolean isDiscoveryUrl(String url) {
        return url.contains("/events/search") || url.endsWith("/events/") || url.contains("/events/discovery");
    }

    private void handleFacebookPage(String url) {
        if(isDiscoveryUrl(url)) {
            // Scroll several times so Facebook lazy-loads more cards.
            fbWeb.evaluateJavascript("(async()=>{for(let i=0;i<4;i++){window.scrollBy(0,2200);await new Promise(r=>setTimeout(r,450));}return true})()", v -> {
                main.postDelayed(() -> fbWeb.evaluateJavascript(
                    "JSON.stringify(Array.from(document.querySelectorAll('a[href*=\"/events/\"]')).map(a=>a.href).filter(h=>/\\/events\\/\\d+/.test(h)))",
                    result -> {
                        try {
                            String decoded = new JSONArray("["+result+"]").getString(0);
                            JSONArray a = new JSONArray(decoded);
                            for(int i=0;i<a.length();i++) {
                                String h=a.getString(i);
                                Matcher m=Pattern.compile("(https://(?:www\\.)?facebook\\.com/events/\\d+)").matcher(h);
                                if(m.find()) fbEventLinks.add(m.group(1));
                            }
                        } catch(Exception ignored){}
                        status("Found "+fbEventLinks.size()+" event links…");
                        loadNextDiscovery();
                    }), 500);
            });
        } else if(url.matches(".*facebook\\.com/events/\\d+.*")) {
            String js =
                "(()=>{let ld='';document.querySelectorAll('script[type=\"application/ld+json\"]').forEach(s=>{if(!ld&&s.textContent.includes('Event'))ld=s.textContent});"+
                "return JSON.stringify({url:location.href,title:document.title,ld:ld,body:document.body.innerText.slice(0,12000)})})()";
            fbWeb.evaluateJavascript(js, result -> {
                parseFacebookDetailResult(result);
                loadNextDetail();
            });
        }
    }

    private void loadNextDetail() {
        if(detailIndex>=fbDetailQueue.size()) {
            finishRefresh();
            return;
        }
        String url=fbDetailQueue.get(detailIndex++);
        status("Facebook "+detailIndex+" / "+fbDetailQueue.size());
        fbWeb.loadUrl(url);
    }

    private void parseFacebookDetailResult(String result) {
        try {
            String decoded = new JSONArray("["+result+"]").getString(0);
            JSONObject raw=new JSONObject(decoded);
            String url=raw.optString("url");
            String title=raw.optString("title").replace(" | Facebook","");
            String body=raw.optString("body");
            String ldRaw=raw.optString("ld");

            String start="", venue="", address="", desc="";
            Double lat=null,lng=null;
            if(!ldRaw.isEmpty()) {
                Object x=new org.json.JSONTokener(ldRaw).nextValue();
                JSONObject ld=null;
                if(x instanceof JSONObject) ld=(JSONObject)x;
                else if(x instanceof JSONArray && ((JSONArray)x).length()>0) ld=((JSONArray)x).optJSONObject(0);
                if(ld!=null) {
                    title=ld.optString("name",title);
                    start=ld.optString("startDate","");
                    desc=ld.optString("description","");
                    JSONObject loc=ld.optJSONObject("location");
                    if(loc!=null) {
                        venue=loc.optString("name","");
                        Object addr=loc.opt("address");
                        if(addr instanceof JSONObject) {
                            JSONObject a=(JSONObject)addr;
                            StringBuilder ab=new StringBuilder();
                            for(String k:new String[]{"streetAddress","addressLocality","addressRegion","postalCode"}) {
                                String v=a.optString(k,""); if(!v.isEmpty()){if(ab.length()>0)ab.append(", ");ab.append(v);}
                            }
                            address=ab.toString();
                        } else if(addr!=null) address=String.valueOf(addr);
                        JSONObject geo=loc.optJSONObject("geo");
                        if(geo!=null) {
                            if(geo.has("latitude")) lat=geo.optDouble("latitude");
                            if(geo.has("longitude")) lng=geo.optDouble("longitude");
                        }
                    }
                }
            }
            if(start.isEmpty()) start=guessDate(body);
            if(start.isEmpty()) return;
            String placeBlob=(title+" "+venue+" "+address+" "+body).toLowerCase(Locale.ROOT);
            if(!isThessaloniki(placeBlob)) return;

            JSONObject ev=new JSONObject();
            ev.put("id","fb-"+Math.abs(url.hashCode()));
            ev.put("title",title);
            ev.put("start",start);
            ev.put("venue",venue);
            ev.put("address",address);
            ev.put("area",inferArea(placeBlob));
            ev.put("category",classify(title+" "+desc+" "+body));
            ev.put("tags",tags(title+" "+desc+" "+body));
            ev.put("free",containsAny(placeBlob,"free","δωρεάν","ελεύθερη είσοδος"));
            ev.put("description",desc.length()>600?desc.substring(0,600):desc);
            if(lat!=null)ev.put("latitude",lat);
            if(lng!=null)ev.put("longitude",lng);
            JSONArray src=new JSONArray(); src.put(new JSONObject().put("name","Facebook").put("url",canonicalFb(url)));
            ev.put("sources",src);
            appendEvent(ev);
        } catch(Exception ignored){}
    }

    private String canonicalFb(String u) {
        Matcher m=Pattern.compile("(https://(?:www\\.)?facebook\\.com/events/\\d+)").matcher(u);
        return m.find()?m.group(1):u;
    }

    private boolean isThessaloniki(String s) {
        return containsAny(s,"thessaloniki","θεσσαλον","kalamaria","καλαμαρ","pylaia","πυλα",
                "thermi","θέρμη","stavroupoli","σταυρούπο","sykies","συκι","evosmos","εύοσμ",
                "toumba","τούμπα","harilaou","χαριλάου");
    }

    private boolean containsAny(String s,String... xs){for(String x:xs)if(s.contains(x))return true;return false;}

    private String inferArea(String s) {
        if(containsAny(s,"kalamaria","καλαμαριά","aretsou","αρετσού")) return "Kalamaria";
        if(containsAny(s,"pylaia","πυλαία")) return "Pylaia";
        if(containsAny(s,"thermi","θέρμη")) return "Thermi";
        if(containsAny(s,"stavroupoli","σταυρούπολη","μονή λαζαριστών")) return "Stavroupoli";
        if(containsAny(s,"sykies","συκιές")) return "Sykies";
        if(containsAny(s,"evosmos","εύοσμος")) return "Evosmos";
        if(containsAny(s,"toumba","τούμπα")) return "Toumba";
        if(containsAny(s,"harilaou","χαριλάου")) return "Harilaou";
        if(containsAny(s,"ano poli","άνω πόλη")) return "Ano Poli";
        if(containsAny(s,"neapoli","νεάπολη")) return "Neapoli";
        if(containsAny(s,"ladadika","λαδάδικα","navarinou","ναυαρίνου","aristotelous","αριστοτέλους","κέντρο","centre","center"))
            return "Centre";
        return "Other / unknown";
    }

    private String classify(String s0) {
        String s=s0.toLowerCase(Locale.ROOT);
        if(containsAny(s,"concert","live music","music","μουσικ","συναυλ","jazz","rock","orchestra","ορχήστ"))return "Music";
        if(containsAny(s,"party","dj","club","nightlife","πάρτι","techno","house"))return "Nightlife";
        if(containsAny(s,"theatre","theater","θέατρο","παράσταση","stand up","comedy"))return "Theatre";
        if(containsAny(s,"exhibition","έκθεση","gallery","museum","εικασ"))return "Art & Exhibitions";
        if(containsAny(s,"cinema","film","movie","σινεμά","ταινία"))return "Cinema";
        if(containsAny(s,"festival","φεστιβάλ"))return "Festivals";
        if(containsAny(s,"food","wine","beer","φαγη","κρασί","μπύρ","tasting"))return "Food & Drink";
        if(containsAny(s,"workshop","seminar","lecture","conference","εργαστήρ","σεμιν"))return "Talks & Workshops";
        if(containsAny(s,"meetup","community","networking","language exchange"))return "Social & Community";
        if(containsAny(s,"kids","children","family","παιδ","οικογέν"))return "Family";
        if(containsAny(s,"sport","run","race","football","basketball","αθλη"))return "Sports";
        if(containsAny(s,"heritage","history","cultural","πολιτισ","ιστορ"))return "Culture";
        if(containsAny(s,"outdoor","open air","hike","excursion","παραλία"))return "Outdoors";
        if(containsAny(s,"market","bazaar","flea","αγορά","παζάρι"))return "Markets";
        return "Other";
    }

    private JSONArray tags(String s0) {
        String s=s0.toLowerCase(Locale.ROOT); JSONArray a=new JSONArray();
        if(containsAny(s,"live","concert","συναυλ"))a.put("Live");
        if(containsAny(s,"electronic","techno","house","dj"))a.put("Electronic");
        if(containsAny(s,"outdoor","open air","παραλία","κήπου"))a.put("Outdoor");
        if(containsAny(s,"classical","orchestra","κλασικ","ορχήστ"))a.put("Classical");
        if(containsAny(s,"comedy","stand up","κωμ"))a.put("Comedy");
        if(containsAny(s,"kids","children","παιδ"))a.put("Kids");
        if(containsAny(s,"networking","meetup"))a.put("Networking");
        return a;
    }

    private String guessDate(String body) {
        // Best effort fallback for English Facebook UI.
        try {
            Pattern p=Pattern.compile("(?i)(January|February|March|April|May|June|July|August|September|October|November|December)\\s+(\\d{1,2})(?:,\\s*(\\d{4}))?.{0,35}?(\\d{1,2}):(\\d{2})\\s*(AM|PM)?");
            Matcher m=p.matcher(body);
            if(!m.find())return "";
            Map<String,Integer> mon=new HashMap<>();
            String[] ms={"January","February","March","April","May","June","July","August","September","October","November","December"};
            for(int i=0;i<ms.length;i++)mon.put(ms[i].toLowerCase(),i+1);
            int year=m.group(3)==null?OffsetDateTime.now().getYear():Integer.parseInt(m.group(3));
            int hour=Integer.parseInt(m.group(4)); String ap=m.group(6);
            if(ap!=null && ap.equalsIgnoreCase("PM") && hour<12)hour+=12;
            if(ap!=null && ap.equalsIgnoreCase("AM") && hour==12)hour=0;
            return OffsetDateTime.of(year,mon.get(m.group(1).toLowerCase()),Integer.parseInt(m.group(2)),
                    hour,Integer.parseInt(m.group(5)),0,0, ZoneOffset.ofHours(3)).toString();
        } catch(Exception e){return "";}
    }

    private synchronized void appendEvent(JSONObject ev) {
        try {
            JSONArray arr=new JSONArray(prefs.getString("events_json","[]"));
            String id=ev.optString("id");
            for(int i=0;i<arr.length();i++) {
                if(id.equals(arr.getJSONObject(i).optString("id"))) { arr.put(i,ev); saveArray(arr); return; }
            }
            arr.put(ev); saveArray(arr);
        } catch(Exception ignored){}
    }

    private void saveArray(JSONArray a) {
        prefs.edit().putString("events_json",a.toString()).apply();
    }

    private void finishRefresh() {
        status("Adding ThessalonikiGuide + AllEvents…");
        exec.submit(() -> {
            try { collectListingSource("https://www.thessalonikiguide.gr/event/","ThessalonikiGuide",80); } catch(Exception ignored){}
            try { collectListingSource("https://allevents.in/thessaloniki/all","AllEvents",80); } catch(Exception ignored){}
            refreshRunning=false;
            String now=OffsetDateTime.now().toString();
            prefs.edit().putString("last_updated",now).putString("status","Updated").apply();
            main.post(() -> {
                status("Updated");
                appWeb.evaluateJavascript("window.nativeRefreshDone && window.nativeRefreshDone()",null);
            });
        });
    }

    private String httpGet(String url) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(20000);
        c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/139 Mobile Safari/537.36");
        c.setRequestProperty("Accept-Language","en-US,en;q=0.9,el;q=0.8");
        BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder sb=new StringBuilder(); String line;
        while((line=br.readLine())!=null) sb.append(line).append('\n');
        br.close(); return sb.toString();
    }

    private void collectListingSource(String listing,String source,int max) throws Exception {
        String html=httpGet(listing);
        LinkedHashSet<String> links=new LinkedHashSet<>();
        Matcher m=Pattern.compile("href=[\\\"'](https?://[^\\\"']+|/[^\\\"']+)[\\\"']",Pattern.CASE_INSENSITIVE).matcher(html);
        while(m.find() && links.size()<max*3) {
            String h=m.group(1).replace("&amp;","&");
            if(h.startsWith("/")) {
                if(source.equals("ThessalonikiGuide")) h="https://www.thessalonikiguide.gr"+h;
                else h="https://allevents.in"+h;
            }
            if(source.equals("ThessalonikiGuide")) {
                if(h.contains("thessalonikiguide.gr/event/") && !h.replaceAll("/$","").equals("https://www.thessalonikiguide.gr/event")) links.add(h);
            } else {
                if(h.contains("allevents.in/thessaloniki/") &&
                   !h.matches(".*?/thessaloniki/(all|calendar|live|music|parties|concerts|today|this-weekend)/?$")) links.add(h);
            }
        }
        int n=0;
        for(String u:links) {
            if(n++>=max)break;
            try {
                JSONObject e=parseJsonLdEvent(httpGet(u),u,source);
                if(e!=null) appendEvent(e);
            } catch(Exception ignored){}
        }
    }

    private JSONObject parseJsonLdEvent(String html,String url,String source) {
        try {
            Matcher sm=Pattern.compile("<script[^>]+type=[\\\"']application/ld\\+json[\\\"'][^>]*>(.*?)</script>",
                    Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(html);
            while(sm.find()) {
                String raw=sm.group(1).trim().replace("&quot;","\\\"");
                Object root=new org.json.JSONTokener(raw).nextValue();
                ArrayList<JSONObject> objs=new ArrayList<>();
                if(root instanceof JSONObject) {
                    JSONObject ro=(JSONObject)root;
                    JSONArray graph=ro.optJSONArray("@graph");
                    if(graph!=null) for(int i=0;i<graph.length();i++) if(graph.optJSONObject(i)!=null) objs.add(graph.optJSONObject(i));
                    objs.add(ro);
                } else if(root instanceof JSONArray) {
                    JSONArray a=(JSONArray)root; for(int i=0;i<a.length();i++) if(a.optJSONObject(i)!=null) objs.add(a.optJSONObject(i));
                }
                for(JSONObject ld:objs) {
                    String typ=String.valueOf(ld.opt("@type"));
                    if(!typ.toLowerCase(Locale.ROOT).contains("event"))continue;
                    String title=ld.optString("name",""), start=ld.optString("startDate","");
                    if(title.isEmpty()||start.isEmpty())continue;
                    String desc=ld.optString("description","");
                    String venue="",address=""; Double lat=null,lng=null;
                    JSONObject loc=ld.optJSONObject("location");
                    if(loc!=null) {
                        venue=loc.optString("name","");
                        Object aa=loc.opt("address");
                        if(aa instanceof JSONObject) {
                            JSONObject a=(JSONObject)aa;
                            address=(a.optString("streetAddress","")+" "+a.optString("addressLocality","")).trim();
                        } else if(aa!=null) address=String.valueOf(aa);
                        JSONObject geo=loc.optJSONObject("geo");
                        if(geo!=null){if(geo.has("latitude"))lat=geo.optDouble("latitude");if(geo.has("longitude"))lng=geo.optDouble("longitude");}
                    }
                    JSONObject e=new JSONObject();
                    e.put("id",source.toLowerCase(Locale.ROOT).replaceAll("[^a-z]","")+"-"+Math.abs(url.hashCode()));
                    e.put("title",title);e.put("start",start);e.put("venue",venue);e.put("address",address);
                    e.put("area",inferArea((title+" "+venue+" "+address+" "+desc).toLowerCase(Locale.ROOT)));
                    e.put("category",classify(title+" "+desc));e.put("tags",tags(title+" "+desc));
                    e.put("free",containsAny((title+" "+desc).toLowerCase(Locale.ROOT),"free","δωρεάν","ελεύθερη είσοδος"));
                    e.put("description",desc.length()>600?desc.substring(0,600):desc);
                    if(lat!=null)e.put("latitude",lat); if(lng!=null)e.put("longitude",lng);
                    JSONArray src=new JSONArray();src.put(new JSONObject().put("name",source).put("url",url));e.put("sources",src);
                    return e;
                }
            }
        } catch(Exception ignored){}
        return null;
    }
}
