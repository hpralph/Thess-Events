package com.ralph.thessevents;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.graphics.Color;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private FrameLayout root;
    private WebView appWeb, fbWeb;
    private Button fbBackButton;
    private SharedPreferences prefs;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();

    private final LinkedHashSet<String> fbEventLinks = new LinkedHashSet<>();
    private final ArrayList<String> fbDiscoveryQueue = new ArrayList<>();
    private final ArrayList<String> fbDetailQueue = new ArrayList<>();
    private int discoveryIndex = 0, detailIndex = 0;
    private boolean refreshRunning = false;
    private boolean loginMode = false;
    private int loginFallbackStage = 0;
    private Runnable fbTimeout = null;
    private long fbGeneration = 0;

    private static final String[] FB_SEARCHES = new String[] {
            "Thessaloniki events", "Θεσσαλονίκη εκδηλώσεις",
            "Thessaloniki concert", "Thessaloniki live music",
            "Thessaloniki party", "Thessaloniki DJ",
            "Thessaloniki theatre", "Θεσσαλονίκη θέατρο",
            "Thessaloniki exhibition", "Θεσσαλονίκη έκθεση",
            "Thessaloniki festival", "Θεσσαλονίκη φεστιβάλ",
            "Thessaloniki workshop", "Thessaloniki meetup",
            "Thessaloniki market", "Thessaloniki family events"
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("thess_events", MODE_PRIVATE);
        buildUi();
        appWeb.loadUrl("file:///android_asset/index.html");
    }

    private void buildUi() {
        root = new FrameLayout(this);
        setContentView(root);

        appWeb = new WebView(this);
        configure(appWeb);
        appWeb.addJavascriptInterface(new AppBridge(this), "Android");
        root.addView(appWeb, new FrameLayout.LayoutParams(-1,-1));

        fbWeb = new WebView(this);
        configure(fbWeb);
        FrameLayout.LayoutParams hiddenFb = new FrameLayout.LayoutParams(2,2);
        hiddenFb.leftMargin = -20;
        hiddenFb.topMargin = -20;
        root.addView(fbWeb, hiddenFb);
        fbWeb.setAlpha(0.01f);

        fbBackButton = new Button(this);
        fbBackButton.setText("← Back to events");
        fbBackButton.setTextColor(Color.WHITE);
        fbBackButton.setBackgroundColor(Color.rgb(17,24,39));
        fbBackButton.setTextSize(16);
        fbBackButton.setVisibility(View.GONE);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-2,-2);
        bp.leftMargin = 18; bp.topMargin = 18;
        root.addView(fbBackButton,bp);
        fbBackButton.setOnClickListener(v -> exitFacebookLogin());

        fbWeb.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (loginMode) {
                    fbBackButton.setVisibility(View.VISIBLE);
                    fbBackButton.bringToFront();
                    return;
                }
                if (!refreshRunning) return;
                main.postDelayed(() -> handleFacebookPage(url), 1200);
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && request.isForMainFrame()) {
                    if (loginMode) handleFacebookLoginError();
                    else if (refreshRunning) {
                        status("Facebook page failed; continuing…");
                        if(detailIndex>0 && detailIndex<=fbDetailQueue.size()) loadNextDetail();
                        else loadNextDiscovery();
                    }
                }
            }
        });
    }

    private void configure(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setUserAgentString(s.getUserAgentString().replace("; wv", ""));
        w.setWebChromeClient(new WebChromeClient());
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
    }

    private void toast(String s) { main.post(() -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show()); }

    public class AppBridge {
        Context c;
        AppBridge(Context c){this.c=c;}

        @JavascriptInterface public String getEvents() {
            return prefs.getString("events_json", "[]");
        }
        @JavascriptInterface public String getLastUpdated() {
            return prefs.getString("last_updated", "");
        }
        @JavascriptInterface public String getStatus() {
            return prefs.getString("status", "Ready");
        }
        @JavascriptInterface public boolean hasFacebookSession() {
            String cookies = CookieManager.getInstance().getCookie("https://www.facebook.com/");
            return cookies != null && cookies.length() > 20;
        }
        @JavascriptInterface public void loginFacebook() {
            main.post(() -> {
                loginMode = true;
                loginFallbackStage = 0;
                fbWeb.setLayoutParams(new FrameLayout.LayoutParams(-1,-1));
                fbWeb.setAlpha(1f);
                fbWeb.bringToFront();
                fbBackButton.setVisibility(View.VISIBLE);
                fbBackButton.bringToFront();
                fbWeb.loadUrl("https://m.facebook.com/events/");
                toast("Log into Facebook, then tap Back to events.");
            });
        }
        @JavascriptInterface public void refresh() {
            main.post(() -> startRefresh());
        }
        @JavascriptInterface public String getLocation() {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 41);
                return "";
            }
            try {
                LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
                Location loc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if(loc==null) loc=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if(loc==null) return "";
                return loc.getLatitude()+","+loc.getLongitude();
            } catch(Exception e){ return ""; }
        }
    }

    @Override public void onBackPressed() {
        if (loginMode) {
            exitFacebookLogin();
            return;
        }
        if (appWeb.canGoBack()) appWeb.goBack(); else super.onBackPressed();
    }

    private void exitFacebookLogin() {
        loginMode=false;
        fbBackButton.setVisibility(View.GONE);
        fbWeb.stopLoading();
        FrameLayout.LayoutParams hiddenFb = new FrameLayout.LayoutParams(2,2);
        hiddenFb.leftMargin=-20; hiddenFb.topMargin=-20;
        fbWeb.setLayoutParams(hiddenFb);
        fbWeb.setAlpha(0.01f);
        appWeb.bringToFront();
        CookieManager.getInstance().flush();
        appWeb.evaluateJavascript("window.onFacebookLoginClosed && window.onFacebookLoginClosed()", null);
    }

    private void handleFacebookLoginError() {
        if(!loginMode) return;
        loginFallbackStage++;
        if(loginFallbackStage==1) {
            toast("Trying Facebook mobile login…");
            fbWeb.loadUrl("https://m.facebook.com/login.php?next=https%3A%2F%2Fm.facebook.com%2Fevents%2F");
        } else if(loginFallbackStage==2) {
            toast("Trying Facebook basic site…");
            fbWeb.loadUrl("https://mbasic.facebook.com/events/");
        } else {
            toast("Facebook could not load. Returning to events.");
            exitFacebookLogin();
            status("Facebook login failed · other sources still available");
        }
    }

    private void status(String s) {
        prefs.edit().putString("status",s).apply();
        main.post(() -> appWeb.evaluateJavascript("window.setNativeStatus && window.setNativeStatus("+JSONObject.quote(s)+")",null));
    }

    private void startRefresh() {
        if (refreshRunning) {
            status("Refresh already running…");
            return;
        }
        refreshRunning=true;
        prefs.edit().putString("events_json","[]").apply();
        status("Updating ThessalonikiGuide + AllEvents…");

        // Public sources run first and do not depend on Facebook.
        exec.submit(() -> {
            int before = countEvents();
            try {
                status("Reading ThessalonikiGuide…");
                collectListingSource("https://www.thessalonikiguide.gr/event/","ThessalonikiGuide",80);
                collectListingSource(todayGuideUrl(),"ThessalonikiGuide",80);
            } catch(Exception e) {
                status("ThessalonikiGuide unavailable; continuing…");
            }
            int afterGuide = countEvents();
            try {
                status("Reading AllEvents…");
                collectListingSource("https://allevents.in/thessaloniki/today--today","AllEvents",80);
                collectListingSource("https://allevents.in/thessaloniki/all","AllEvents",80);
            } catch(Exception e) {
                status("AllEvents unavailable; continuing…");
            }
            int publicCount = countEvents();

            main.post(() -> {
                String cookies = CookieManager.getInstance().getCookie("https://www.facebook.com/");
                if (cookies == null || cookies.length() < 20) {
                    finishRefreshWithMessage("Updated "+publicCount+" events · Facebook login needed");
                    appWeb.evaluateJavascript("window.needFacebookLogin && window.needFacebookLogin()",null);
                    return;
                }

                fbEventLinks.clear(); fbDiscoveryQueue.clear(); fbDetailQueue.clear();
                discoveryIndex=0; detailIndex=0;
                status("Connecting to Facebook Events…");

                fbDiscoveryQueue.add("https://m.facebook.com/events/");
                fbDiscoveryQueue.add("https://m.facebook.com/events/discovery/");
                for(String q:FB_SEARCHES) {
                    fbDiscoveryQueue.add("https://m.facebook.com/events/search/?q="+
                            URLEncoder.encode(q, StandardCharsets.UTF_8));
                }
                loadNextDiscovery();
            });
        });
    }

    private String todayGuideUrl() {
        int d=java.time.ZonedDateTime.now(java.time.ZoneId.of("Europe/Athens")).getDayOfWeek().getValue();
        String[] days={"","monday","tuesday","wednesday","thursday","friday","saturday","sunday"};
        return "https://www.thessalonikiguide.gr/"+days[d]+"/";
    }

    private int countEvents() {
        try { return new JSONArray(prefs.getString("events_json","[]")).length(); }
        catch(Exception e){ return 0; }
    }

    private void cancelFbTimeout() {
        if(fbTimeout!=null) main.removeCallbacks(fbTimeout);
        fbTimeout=null;
    }

    private void loadFacebookWithTimeout(String url, boolean discovery) {
        cancelFbTimeout();
        fbGeneration++;
        final long gen=fbGeneration;
        fbTimeout=() -> {
            if(!refreshRunning || gen!=fbGeneration) return;
            status(discovery ? "Facebook search timed out; trying next…" : "Facebook event timed out; continuing…");
            if(discovery) loadNextDiscovery(); else loadNextDetail();
        };
        main.postDelayed(fbTimeout, 14000);
        fbWeb.stopLoading();
        fbWeb.loadUrl(url);
    }

    private void loadNextDiscovery() {
        cancelFbTimeout();
        if(discoveryIndex>=fbDiscoveryQueue.size()) {
            fbDetailQueue.addAll(fbEventLinks);
            if(fbDetailQueue.size()>100) fbDetailQueue.subList(100,fbDetailQueue.size()).clear();
            if(fbDetailQueue.isEmpty()) {
                finishRefreshWithMessage("Updated · Facebook returned no event links");
                return;
            }
            status("Facebook: "+fbDetailQueue.size()+" event links found");
            loadNextDetail();
            return;
        }
        String url=fbDiscoveryQueue.get(discoveryIndex++);
        status("Facebook search "+discoveryIndex+" / "+fbDiscoveryQueue.size()+" · "+fbEventLinks.size()+" links");
        loadFacebookWithTimeout(url,true);
    }

    private boolean isDiscoveryUrl(String url) {
        return url.contains("/events/search") || url.endsWith("/events/") || url.contains("/events/discovery");
    }

    private void handleFacebookPage(String url) {
        cancelFbTimeout();
        if(isDiscoveryUrl(url)) {
            // Scroll several times so Facebook lazy-loads more cards.
            fbWeb.evaluateJavascript("(async()=>{for(let i=0;i<4;i++){window.scrollBy(0,2200);await new Promise(r=>setTimeout(r,450));}return true})()", v -> {
                main.postDelayed(() -> fbWeb.evaluateJavascript(
                    "(()=>{let x=new Set(Array.from(document.querySelectorAll('a[href*=\"/events/\"]')).map(a=>a.href));let html=document.documentElement.innerHTML;for(let m of html.matchAll(/\\/events\\/(\\d+)/g)){x.add('https://m.facebook.com/events/'+m[1]);}return JSON.stringify(Array.from(x).filter(h=>/\\/events\\/\\d+/.test(h)))})()",
                    result -> {
                        try {
                            String decoded = new JSONArray("["+result+"]").getString(0);
                            JSONArray a = new JSONArray(decoded);
                            for(int i=0;i<a.length();i++) {
                                String h=a.getString(i);
                                Matcher m=Pattern.compile("(https://(?:(?:www|m|mbasic)\\.)?facebook\\.com/events/\\d+)").matcher(h);
                                if(m.find()) fbEventLinks.add(m.group(1));
                            }
                        } catch(Exception ignored){}
                        status("Found "+fbEventLinks.size()+" event links…");
                        loadNextDiscovery();
                    }), 500);
            });
        } else if(url.matches(".*facebook\\.com/events/\\d+.*")) {
            String js =
                "(()=>{let ld='';document.querySelectorAll('script[type=\"application/ld+json\"]').forEach(s=>{if(!ld&&s.textContent.includes('Event'))ld=s.textContent});"+
                "return JSON.stringify({url:location.href,title:document.title,ld:ld,body:document.body.innerText.slice(0,12000)})})()";
            fbWeb.evaluateJavascript(js, result -> {
                parseFacebookDetailResult(result);
                loadNextDetail();
            });
        } else {
            status("Facebook redirected; continuing…");
            if(detailIndex>0 && detailIndex<=fbDetailQueue.size()) loadNextDetail();
            else loadNextDiscovery();
        }
    }

    private void loadNextDetail() {
        cancelFbTimeout();
        if(detailIndex>=fbDetailQueue.size()) {
            finishRefreshWithMessage("Updated");
            return;
        }
        String url=fbDetailQueue.get(detailIndex++);
        status("Facebook event "+detailIndex+" / "+fbDetailQueue.size());
        loadFacebookWithTimeout(url,false);
    }

    private void parseFacebookDetailResult(String result) {
        try {
            String decoded = new JSONArray("["+result+"]").getString(0);
            JSONObject raw=new JSONObject(decoded);
            String url=raw.optString("url");
            String title=raw.optString("title").replace(" | Facebook","");
            String body=raw.optString("body");
            String ldRaw=raw.optString("ld");

            String start="", venue="", address="", desc="";
            Double lat=null,lng=null;
            if(!ldRaw.isEmpty()) {
                Object x=new org.json.JSONTokener(ldRaw).nextValue();
                JSONObject ld=null;
                if(x instanceof JSONObject) ld=(JSONObject)x;
                else if(x instanceof JSONArray && ((JSONArray)x).length()>0) ld=((JSONArray)x).optJSONObject(0);
                if(ld!=null) {
                    title=ld.optString("name",title);
                    start=ld.optString("startDate","");
                    desc=ld.optString("description","");
                    JSONObject loc=ld.optJSONObject("location");
                    if(loc!=null) {
                        venue=loc.optString("name","");
                        Object addr=loc.opt("address");
                        if(addr instanceof JSONObject) {
                            JSONObject a=(JSONObject)addr;
                            StringBuilder ab=new StringBuilder();
                            for(String k:new String[]{"streetAddress","addressLocality","addressRegion","postalCode"}) {
                                String v=a.optString(k,""); if(!v.isEmpty()){if(ab.length()>0)ab.append(", ");ab.append(v);}
                            }
                            address=ab.toString();
                        } else if(addr!=null) address=String.valueOf(addr);
                        JSONObject geo=loc.optJSONObject("geo");
                        if(geo!=null) {
                            if(geo.has("latitude")) lat=geo.optDouble("latitude");
                            if(geo.has("longitude")) lng=geo.optDouble("longitude");
                        }
                    }
                }
            }
            if(start.isEmpty()) start=guessDate(body);
            if(start.isEmpty()) return;
            String placeBlob=(title+" "+venue+" "+address+" "+body).toLowerCase(Locale.ROOT);
            if(!isThessaloniki(placeBlob)) return;

            JSONObject ev=new JSONObject();
            ev.put("id","fb-"+Math.abs(url.hashCode()));
            ev.put("title",title);
            ev.put("start",start);
            ev.put("venue",venue);
            ev.put("address",address);
            ev.put("area",inferArea(placeBlob));
            ev.put("category",classify(title+" "+desc+" "+body));
            ev.put("tags",tags(title+" "+desc+" "+body));
            ev.put("free",containsAny(placeBlob,"free","δωρεάν","ελεύθερη είσοδος"));
            ev.put("description",desc.length()>600?desc.substring(0,600):desc);
            if(lat!=null)ev.put("latitude",lat);
            if(lng!=null)ev.put("longitude",lng);
            JSONArray src=new JSONArray(); src.put(new JSONObject().put("name","Facebook").put("url",canonicalFb(url)));
            ev.put("sources",src);
            appendEvent(ev);
        } catch(Exception ignored){}
    }

    private String canonicalFb(String u) {
        Matcher m=Pattern.compile("(https://(?:(?:www|m|mbasic)\\.)?facebook\\.com/events/\\d+)").matcher(u);
        return m.find()?m.group(1):u;
    }

    private boolean isThessaloniki(String s) {
        return containsAny(s,"thessaloniki","θεσσαλον","kalamaria","καλαμαρ","pylaia","πυλα",
                "thermi","θέρμη","stavroupoli","σταυρούπο","sykies","συκι","evosmos","εύοσμ",
                "toumba","τούμπα","harilaou","χαριλάου");
    }

    private boolean containsAny(String s,String... xs){for(String x:xs)if(s.contains(x))return true;return false;}

    private String inferArea(String s) {
        if(containsAny(s,"kalamaria","καλαμαριά","aretsou","αρετσού")) return "Kalamaria";
        if(containsAny(s,"pylaia","πυλαία")) return "Pylaia";
        if(containsAny(s,"thermi","θέρμη")) return "Thermi";
        if(containsAny(s,"stavroupoli","σταυρούπολη","μονή λαζαριστών")) return "Stavroupoli";
        if(containsAny(s,"sykies","συκιές")) return "Sykies";
        if(containsAny(s,"evosmos","εύοσμος")) return "Evosmos";
        if(containsAny(s,"toumba","τούμπα")) return "Toumba";
        if(containsAny(s,"harilaou","χαριλάου")) return "Harilaou";
        if(containsAny(s,"ano poli","άνω πόλη")) return "Ano Poli";
        if(containsAny(s,"neapoli","νεάπολη")) return "Neapoli";
        if(containsAny(s,"ladadika","λαδάδικα","navarinou","ναυαρίνου","aristotelous","αριστοτέλους","κέντρο","centre","center"))
            return "Centre";
        return "Other / unknown";
    }

    private String classify(String s0) {
        String s=s0.toLowerCase(Locale.ROOT);
        if(containsAny(s,"concert","live music","music","μουσικ","συναυλ","jazz","rock","orchestra","ορχήστ"))return "Music";
        if(containsAny(s,"party","dj","club","nightlife","πάρτι","techno","house"))return "Nightlife";
        if(containsAny(s,"theatre","theater","θέατρο","παράσταση","stand up","comedy"))return "Theatre";
        if(containsAny(s,"exhibition","έκθεση","gallery","museum","εικασ"))return "Art & Exhibitions";
        if(containsAny(s,"cinema","film","movie","σινεμά","ταινία"))return "Cinema";
        if(containsAny(s,"festival","φεστιβάλ"))return "Festivals";
        if(containsAny(s,"food","wine","beer","φαγη","κρασί","μπύρ","tasting"))return "Food & Drink";
        if(containsAny(s,"workshop","seminar","lecture","conference","εργαστήρ","σεμιν"))return "Talks & Workshops";
        if(containsAny(s,"meetup","community","networking","language exchange"))return "Social & Community";
        if(containsAny(s,"kids","children","family","παιδ","οικογέν"))return "Family";
        if(containsAny(s,"sport","run","race","football","basketball","αθλη"))return "Sports";
        if(containsAny(s,"heritage","history","cultural","πολιτισ","ιστορ"))return "Culture";
        if(containsAny(s,"outdoor","open air","hike","excursion","παραλία"))return "Outdoors";
        if(containsAny(s,"market","bazaar","flea","αγορά","παζάρι"))return "Markets";
        if(containsAny(s,"magic the gathering","mtg","board game","boardgame","tabletop","card game","tcg","gaming","tournament","dungeons & dragons","pokemon","pokémon"))return "Games / Gaming";
        return "Other";
    }

    private JSONArray tags(String s0) {
        String s=s0.toLowerCase(Locale.ROOT); JSONArray a=new JSONArray();
        if(containsAny(s,"live","concert","συναυλ"))a.put("Live");
        if(containsAny(s,"electronic","techno","house","dj"))a.put("Electronic");
        if(containsAny(s,"outdoor","open air","παραλία","κήπου"))a.put("Outdoor");
        if(containsAny(s,"classical","orchestra","κλασικ","ορχήστ"))a.put("Classical");
        if(containsAny(s,"comedy","stand up","κωμ"))a.put("Comedy");
        if(containsAny(s,"kids","children","παιδ"))a.put("Kids");
        if(containsAny(s,"networking","meetup"))a.put("Networking");
        return a;
    }

    private String guessDate(String body) {
        // Best effort fallback for English Facebook UI.
        try {
            Pattern p=Pattern.compile("(?i)(January|February|March|April|May|June|July|August|September|October|November|December)\\s+(\\d{1,2})(?:,\\s*(\\d{4}))?.{0,35}?(\\d{1,2}):(\\d{2})\\s*(AM|PM)?");
            Matcher m=p.matcher(body);
            if(!m.find())return "";
            Map<String,Integer> mon=new HashMap<>();
            String[] ms={"January","February","March","April","May","June","July","August","September","October","November","December"};
            for(int i=0;i<ms.length;i++)mon.put(ms[i].toLowerCase(),i+1);
            int year=m.group(3)==null?OffsetDateTime.now().getYear():Integer.parseInt(m.group(3));
            int hour=Integer.parseInt(m.group(4)); String ap=m.group(6);
            if(ap!=null && ap.equalsIgnoreCase("PM") && hour<12)hour+=12;
            if(ap!=null && ap.equalsIgnoreCase("AM") && hour==12)hour=0;
            return OffsetDateTime.of(year,mon.get(m.group(1).toLowerCase()),Integer.parseInt(m.group(2)),
                    hour,Integer.parseInt(m.group(5)),0,0, ZoneOffset.ofHours(3)).toString();
        } catch(Exception e){return "";}
    }

    private synchronized void appendEvent(JSONObject ev) {
        try {
            JSONArray arr=new JSONArray(prefs.getString("events_json","[]"));
            String key=eventExactKey(ev);
            for(int i=0;i<arr.length();i++) {
                JSONObject old=arr.getJSONObject(i);
                if(!key.isEmpty() && key.equals(eventExactKey(old))) { mergeEvent(old,ev); arr.put(i,old); saveArray(arr); return; }
                double ts=jaccard(old.optString("title"),ev.optString("title"));
                double vs=jaccard(old.optString("venue"),ev.optString("venue"));
                if(ts>=0.84 && sameDay(old.optString("start"),ev.optString("start")) && (vs>=0.35 || sameMinute(old.optString("start"),ev.optString("start")))) {
                    mergeEvent(old,ev); arr.put(i,old); saveArray(arr); return;
                }
            }
            arr.put(ev); saveArray(arr);
        } catch(Exception ignored){}
    }

    private String eventExactKey(JSONObject e) {
        try { String t=normalizeKey(e.optString("title")), s=e.optString("start"); if(t.isEmpty()||s.length()<16)return ""; return t+"|"+s.substring(0,16); } catch(Exception e1){return "";}
    }
    private void mergeEvent(JSONObject old,JSONObject newer) throws Exception {
        JSONArray os=old.optJSONArray("sources"); if(os==null)os=new JSONArray();
        JSONArray ns=newer.optJSONArray("sources");
        if(ns!=null) for(int j=0;j<ns.length();j++){ JSONObject s=ns.getJSONObject(j); boolean found=false; for(int k=0;k<os.length();k++){JSONObject x=os.getJSONObject(k); if(x.optString("name").equals(s.optString("name"))&&x.optString("url").equals(s.optString("url")))found=true;} if(!found)os.put(s);}
        old.put("sources",os);
        if(newer.optString("description").length()>old.optString("description").length())old.put("description",newer.optString("description"));
        if(old.optString("venue").isEmpty()&&!newer.optString("venue").isEmpty())old.put("venue",newer.optString("venue"));
        old.put("free",old.optBoolean("free")||newer.optBoolean("free"));
    }
    private String normalizeKey(String s){return s.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+"," ").trim();}
    private double jaccard(String a,String b){Set<String>A=new HashSet<>(Arrays.asList(normalizeKey(a).split("\\s+")));Set<String>B=new HashSet<>(Arrays.asList(normalizeKey(b).split("\\s+")));A.remove("");B.remove("");if(A.isEmpty()||B.isEmpty())return 0;Set<String>I=new HashSet<>(A);I.retainAll(B);Set<String>U=new HashSet<>(A);U.addAll(B);return (double)I.size()/U.size();}
    private boolean sameDay(String a,String b){return a.length()>=10&&b.length()>=10&&a.substring(0,10).equals(b.substring(0,10));}
    private boolean sameMinute(String a,String b){return a.length()>=16&&b.length()>=16&&a.substring(0,16).equals(b.substring(0,16));}

    private void saveArray(JSONArray a) {
        prefs.edit().putString("events_json",a.toString()).apply();
    }

    private void finishRefresh() {
        finishRefreshWithMessage("Updated");
    }

    private void finishRefreshWithMessage(String message) {
        cancelFbTimeout();
        refreshRunning=false;
        String now=OffsetDateTime.now().toString();
        prefs.edit().putString("last_updated",now).putString("status",message).apply();
        main.post(() -> {
            status(message);
            appWeb.evaluateJavascript("window.nativeRefreshDone && window.nativeRefreshDone()",null);
        });
    }

    private String httpGet(String url) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(20000);
        c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/139 Mobile Safari/537.36");
        c.setRequestProperty("Accept-Language","en-US,en;q=0.9,el;q=0.8");
        BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder sb=new StringBuilder(); String line;
        while((line=br.readLine())!=null) sb.append(line).append('\n');
        br.close(); return sb.toString();
    }

    private void appendJsonLdEventsFromPage(String html,String pageUrl,String source) {
        try {
            Matcher sm=Pattern.compile("<script[^>]+type=[\"']application/ld\\+json[\"'][^>]*>(.*?)</script>",Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(html);
            while(sm.find()) {
                try {
                    String raw=sm.group(1).trim().replace("&quot;","\"").replace("&amp;","&").replace("&#039;","'");
                    Object root=new org.json.JSONTokener(raw).nextValue();
                    ArrayList<JSONObject> evs=new ArrayList<>();
                    collectEventObjects(root,evs);
                    for(JSONObject ld:evs) {
                        String title=ld.optString("name",""); String start=ld.optString("startDate",""); if(title.isEmpty()||start.isEmpty())continue;
                        String desc=ld.optString("description",""); String venue="",address=""; Double lat=null,lng=null;
                        Object lo=ld.opt("location"); if(lo instanceof JSONObject){JSONObject loc=(JSONObject)lo;venue=loc.optString("name","");Object aa=loc.opt("address");if(aa instanceof JSONObject){JSONObject a=(JSONObject)aa;address=(a.optString("streetAddress","")+" "+a.optString("addressLocality","")).trim();}else if(aa!=null)address=String.valueOf(aa);JSONObject geo=loc.optJSONObject("geo");if(geo!=null){if(geo.has("latitude"))lat=geo.optDouble("latitude");if(geo.has("longitude"))lng=geo.optDouble("longitude");}}
                        String eventUrl=ld.optString("url",pageUrl); JSONObject e=new JSONObject();
                        e.put("id",source.toLowerCase(Locale.ROOT).replaceAll("[^a-z]","")+"-list-"+Math.abs((eventUrl+start+title).hashCode()));e.put("title",title);e.put("start",start);e.put("venue",venue);e.put("address",address);e.put("area",inferArea((title+" "+venue+" "+address+" "+desc).toLowerCase(Locale.ROOT)));e.put("category",classify(title+" "+desc));e.put("tags",tags(title+" "+desc));e.put("free",containsAny((title+" "+desc).toLowerCase(Locale.ROOT),"free","δωρεάν","ελεύθερη είσοδος"));e.put("description",desc.length()>600?desc.substring(0,600):desc);if(lat!=null)e.put("latitude",lat);if(lng!=null)e.put("longitude",lng);JSONArray src=new JSONArray();src.put(new JSONObject().put("name",source).put("url",eventUrl));e.put("sources",src);appendEvent(e);
                    }
                } catch(Exception ignored){}
            }
        } catch(Exception ignored){}
    }

    private void collectEventObjects(Object root,ArrayList<JSONObject> out) {
        try {
            if(root instanceof JSONObject){JSONObject o=(JSONObject)root;String typ=String.valueOf(o.opt("@type")).toLowerCase(Locale.ROOT);if(typ.contains("event"))out.add(o);Iterator<String>it=o.keys();while(it.hasNext()){Object v=o.opt(it.next());if(v instanceof JSONObject||v instanceof JSONArray)collectEventObjects(v,out);}}
            else if(root instanceof JSONArray){JSONArray a=(JSONArray)root;for(int i=0;i<a.length();i++){Object v=a.opt(i);if(v instanceof JSONObject||v instanceof JSONArray)collectEventObjects(v,out);}}
        } catch(Exception ignored){}
    }

    private void collectListingSource(String listing,String source,int max) throws Exception {
        String html=httpGet(listing);
        appendJsonLdEventsFromPage(html,listing,source);
        LinkedHashSet<String> links=new LinkedHashSet<>();
        Matcher m=Pattern.compile("href=[\\\"'](https?://[^\\\"']+|/[^\\\"']+)[\\\"']",Pattern.CASE_INSENSITIVE).matcher(html);
        while(m.find() && links.size()<max*3) {
            String h=m.group(1).replace("&amp;","&");
            if(h.startsWith("/")) {
                if(source.equals("ThessalonikiGuide")) h="https://www.thessalonikiguide.gr"+h;
                else h="https://allevents.in"+h;
            }
            if(source.equals("ThessalonikiGuide")) {
                if(h.contains("thessalonikiguide.gr/event/") && !h.replaceAll("/$","").equals("https://www.thessalonikiguide.gr/event")) links.add(h);
            } else {
                if(h.contains("allevents.in/thessaloniki/") &&
                   !h.matches(".*?/thessaloniki/(all|calendar|live|music|parties|concerts|today|this-weekend)/?$")) links.add(h);
            }
        }
        int n=0;
        for(String u:links) {
            if(n++>=max)break;
            status(source+" "+n+" / "+Math.min(max,links.size()));
            try {
                String pageHtml=httpGet(u);
                JSONObject e=parseJsonLdEvent(pageHtml,u,source);
                if(e!=null) {
                    if(source.equals("ThessalonikiGuide")) { int added=appendGuideOccurrences(pageHtml,e); if(added==0)appendEvent(e); }
                    else appendEvent(e);
                }
            } catch(Exception ignored){}
        }
    }

    private int appendGuideOccurrences(String html,JSONObject base) {
        int added=0;
        try {
            String text=html.replaceAll("(?is)<script.*?</script>"," ").replaceAll("(?is)<style.*?</style>"," ").replaceAll("(?is)<[^>]+>"," ").replace("&nbsp;"," ").replace("&amp;","&").replaceAll("\\s+"," ");
            Pattern p=Pattern.compile("(?:Δε|Τρ|Τε|Πε|Πα|Σα|Κυ)\\s+(\\d{1,2})/(\\d{2})(?:\\s+(\\d{1,2}:\\d{2}))?");
            Matcher m=p.matcher(text); int year=java.time.ZonedDateTime.now(java.time.ZoneId.of("Europe/Athens")).getYear(); HashSet<String>seen=new HashSet<>();
            while(m.find()){int day=Integer.parseInt(m.group(1)), mon=Integer.parseInt(m.group(2)); String tm=m.group(3)==null?"00:00":m.group(3); String k=day+"/"+mon+" "+tm; if(seen.contains(k))continue;seen.add(k); JSONObject copy=new JSONObject(base.toString()); String iso=String.format(Locale.ROOT,"%04d-%02d-%02dT%s:00+03:00",year,mon,day,tm); copy.put("start",iso);copy.put("id",base.optString("id")+"-"+day+"-"+mon+"-"+tm.replace(":","")); appendEvent(copy);added++;}
        }catch(Exception ignored){}
        return added;
    }

    private JSONObject parseJsonLdEvent(String html,String url,String source) {
        try {
            Matcher sm=Pattern.compile("<script[^>]+type=[\\\"']application/ld\\+json[\\\"'][^>]*>(.*?)</script>",
                    Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(html);
            while(sm.find()) {
                String raw=sm.group(1).trim().replace("&quot;","\\\"").replace("&amp;","&").replace("&#039;","'");
                Object root=new org.json.JSONTokener(raw).nextValue();
                ArrayList<JSONObject> objs=new ArrayList<>();
                if(root instanceof JSONObject) {
                    JSONObject ro=(JSONObject)root;
                    JSONArray graph=ro.optJSONArray("@graph");
                    if(graph!=null) for(int i=0;i<graph.length();i++) if(graph.optJSONObject(i)!=null) objs.add(graph.optJSONObject(i));
                    objs.add(ro);
                } else if(root instanceof JSONArray) {
                    JSONArray a=(JSONArray)root; for(int i=0;i<a.length();i++) if(a.optJSONObject(i)!=null) objs.add(a.optJSONObject(i));
                }
                for(JSONObject ld:objs) {
                    String typ=String.valueOf(ld.opt("@type"));
                    if(!typ.toLowerCase(Locale.ROOT).contains("event"))continue;
                    String title=ld.optString("name",""), start=ld.optString("startDate","");
                    if(title.isEmpty()||start.isEmpty())continue;
                    String desc=ld.optString("description","");
                    String venue="",address=""; Double lat=null,lng=null;
                    JSONObject loc=ld.optJSONObject("location");
                    if(loc!=null) {
                        venue=loc.optString("name","");
                        Object aa=loc.opt("address");
                        if(aa instanceof JSONObject) {
                            JSONObject a=(JSONObject)aa;
                            address=(a.optString("streetAddress","")+" "+a.optString("addressLocality","")).trim();
                        } else if(aa!=null) address=String.valueOf(aa);
                        JSONObject geo=loc.optJSONObject("geo");
                        if(geo!=null){if(geo.has("latitude"))lat=geo.optDouble("latitude");if(geo.has("longitude"))lng=geo.optDouble("longitude");}
                    }
                    JSONObject e=new JSONObject();
                    e.put("id",source.toLowerCase(Locale.ROOT).replaceAll("[^a-z]","")+"-"+Math.abs(url.hashCode()));
                    e.put("title",title);e.put("start",start);e.put("venue",venue);e.put("address",address);
                    e.put("area",inferArea((title+" "+venue+" "+address+" "+desc).toLowerCase(Locale.ROOT)));
                    e.put("category",classify(title+" "+desc));e.put("tags",tags(title+" "+desc));
                    e.put("free",containsAny((title+" "+desc).toLowerCase(Locale.ROOT),"free","δωρεάν","ελεύθερη είσοδος"));
                    e.put("description",desc.length()>600?desc.substring(0,600):desc);
                    if(lat!=null)e.put("latitude",lat); if(lng!=null)e.put("longitude",lng);
                    JSONArray src=new JSONArray();src.put(new JSONObject().put("name",source).put("url",url));e.put("sources",src);
                    return e;
                }
            }
        } catch(Exception ignored){}
        return null;
    }
}
