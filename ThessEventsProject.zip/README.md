# Thess Events Android v0.5

Fixes in this build:
- Second-pass render-time deduplication prevents identical AllEvents cards from being shown twice.
- ThessalonikiGuide no longer depends only on Event JSON-LD: it falls back to the page's H1, description and 'Ημέρες & Ώρες' section.
- Facebook discovery uses both Facebook search/events routes and extracts event IDs from visible links and embedded page data.
- Facebook events are no longer discarded just because Facebook omitted the word Thessaloniki from a detail page.
- Card descriptions are stored much longer and the UI expands/collapses the full text when tapped.
- Greek event titles/descriptions can be translated to English on-device with ML Kit. No API key is needed; the Greek model downloads once.
- Games / Gaming category retained.
