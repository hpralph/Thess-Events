# Thess Events Android v0.3

This build fixes the refresh hang seen on Android.

Changes:
- Facebook collector WebView stays active off-screen instead of being GONE.
- Every Facebook page has a 14-second timeout; one bad page can no longer freeze the refresh.
- Detailed progress messages: public sources, Facebook searches, links found, event X/Y.
- ThessalonikiGuide and AllEvents now refresh first, independently of Facebook login.
- The app continues if one source fails.
- Filter chips wrap properly on narrow phone screens.
- The local event cache is rebuilt and deduplicated on each refresh.

No server, Apify token, or paid API is required.

To update:
Upload this project's ZIP to GitHub with the filename `ThessEventsProject.zip`, replacing the previous one.
Your existing GitHub Actions workflow will build the new APK automatically.
