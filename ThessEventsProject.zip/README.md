# Thess Events Android

A no-server Android prototype. It keeps the event database and Facebook session on the phone.

## What it does
- One-time Facebook login inside the app.
- On app open / refresh, it visits Facebook Events plus multiple Thessaloniki search queries automatically.
- It extracts public Facebook event links and reads event pages.
- Events are cached locally.
- Automatic categories/tags.
- Filters: Today, Tomorrow, Weekend, next 7 days, multiple categories, area, source, Facebook-only, free, and 2/5/10/20 km.
- No Apify token, paid server or manual event entry.

## Important prototype limitation
Facebook is not an official public events API. Its HTML and anti-automation behavior can change, so the collector may occasionally need an update. It searches within your logged-in WebView session and does not read or store your Facebook password.

This first Android build focuses on Facebook because that is the difficult unique source. The UI already supports ThessalonikiGuide and AllEvents sources, but their phone-only collectors should be added after Facebook behavior is tested on a real device.

## Build the APK for free
The repository includes `.github/workflows/build-apk.yml`. GitHub Actions can build `app-debug.apk` without a server/API subscription.

1. Create a GitHub repository.
2. Upload this project (keeping the folder structure).
3. Open **Actions → Build Android APK → Run workflow**.
4. When it finishes, download the `ThessEvents-debug-apk` artifact.
5. Extract it and install `app-debug.apk` on Android. Android may ask you to allow installs from your browser/files app.

## First use
1. Open Thess Events.
2. Tap **Log into Facebook**.
3. Log in on the real Facebook page shown inside the app.
4. When Facebook Events loads, press Android **Back**.
5. Tap **Refresh**. After that, opening the app triggers a refresh automatically.

## Privacy
The Facebook cookies/session stay in Android WebView storage on your phone. Do not distribute an APK modified to export WebView cookies.

## Status
Prototype v0.1. The Facebook collector must be validated against the current Facebook mobile/WebView pages on your specific Android device before it can be considered production-stable.
