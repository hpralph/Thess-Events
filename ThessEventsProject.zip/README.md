# Thess Events Android v0.4

Fixes mobile Facebook URL extraction, Facebook login escape/fallback, exact deduplication, ThessalonikiGuide multi-day occurrence expansion, explicit today-page collection, and Games / Gaming categorisation.
